﻿namespace $safeprojectname$
{
    public class ProjectAutoMap : AutoMapper.Profile
    {
        
        public ProjectAutoMap()
        {
        }
    }
}
﻿using System;

namespace $safeprojectname$
{
    [AttributeUsage(AttributeTargets.Assembly)]
    public class DeleteBoilerplateAssemblyAttribute : Attribute
    {
    }
}

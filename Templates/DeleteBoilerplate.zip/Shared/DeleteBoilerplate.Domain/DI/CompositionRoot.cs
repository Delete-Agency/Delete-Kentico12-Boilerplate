﻿using $safeprojectname$.Repositories;
using $safeprojectname$.Services;
using LightInject;

namespace $safeprojectname$
{
    public class CompositionRoot : ICompositionRoot
    {
        public void Compose(IServiceRegistry serviceRegistry)
        {
            serviceRegistry.RegisterScoped<IProjectRepository, ProjectRepository>();
            serviceRegistry.RegisterScoped<ITaxonomyRepository, TaxonomyRepository>();
            serviceRegistry.Register(typeof(ITaxonomySearch<>),typeof(TaxonomySearch<>), new PerScopeLifetime());
            serviceRegistry.RegisterScoped<ITaxonomyService, TaxonomyService>();
            serviceRegistry.RegisterScoped<ISocialLinksRepository, SocialLinksRepository>();
            serviceRegistry.RegisterScoped<INavigationRepository, NavigationRepository>();
        }
    }
}
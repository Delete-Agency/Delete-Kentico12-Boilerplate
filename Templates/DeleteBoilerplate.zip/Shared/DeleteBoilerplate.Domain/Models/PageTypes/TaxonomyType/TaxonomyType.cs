﻿using System.Collections.Generic;

namespace CMS.DocumentEngine.Types.DeleteBoilerplate
{
    public partial class TaxonomyType
    {
        public IEnumerable<TaxonomyItem> TaxonomyItems { get; set; }
    }
}

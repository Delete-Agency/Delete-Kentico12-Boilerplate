﻿using $safeprojectname$.Models.PageTypes;

namespace CMS.DocumentEngine.Types.DeleteBoilerplate
{
    public partial class BasePage : IBasePage
    {

    }
}
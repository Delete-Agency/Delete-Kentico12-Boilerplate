﻿namespace CMS.DocumentEngine.Types.DeleteBoilerplate
{
    public partial class TaxonomyItem
    {
        public TaxonomyType TaxonomyType { get; set; }
    }
}
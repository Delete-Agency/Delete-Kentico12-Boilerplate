﻿using System.Web.Mvc;
using AutoMapper;
using DeleteBoilerplate.DynamicRouting.Controllers;
using $safeprojectname$.Controllers.Widgets;
using $safeprojectname$.Models.Widgets.ImageWidget;
using Kentico.PageBuilder.Web.Mvc;
using LightInject;

[assembly:
    RegisterWidget("$safeprojectname$.ImageWidget", typeof(ImageWidgetController),
        "{$DeleteBoilerplate.Widget.Image.Name$}", Description = "{$DeleteBoilerplate.Widget.Image.Description$}",
        IconClass = "icon-rectangle-o-h")]

namespace $safeprojectname$.Controllers.Widgets
{
    public class ImageWidgetController : BaseWidgetController<ImageWidgetProperties>
    {
        [Inject]
        public IMapper Mapper { get; set; }

        public ActionResult Index()
        {
            var properties = GetProperties();

            return PartialView("Widgets/_Image", Mapper.Map<ImageWidgetViewModel>(properties));
        }
    }
}
﻿using DeleteBoilerplate.Infrastructure.Models;

namespace $safeprojectname$.Models.InlineEditors
{
    public class ImageSelectorViewModel : BaseInlineEditorViewModel
    {
    }
}
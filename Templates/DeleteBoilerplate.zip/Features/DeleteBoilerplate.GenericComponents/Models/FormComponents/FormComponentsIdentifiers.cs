﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.FormComponents
{
    public static class FormComponentsIdentifiers
    {
        public const string TaxonomySelector = "Laureus.TaxonomySelector";
    }
}
﻿using System.Collections.Generic;
using DeleteBoilerplate.Infrastructure.Models;

namespace $safeprojectname$.Models.Widgets.ImageWidget
{
    public class ImageWidgetViewModel : BaseWidgetViewModel
    {
        public IList<ImageViewModel> Images { get; set; }
    }
}
﻿namespace $safeprojectname$.Models.Widgets
{
    public interface ITaxonomyWidgetProperties
    {
        string Type { get; set; }
    }
}
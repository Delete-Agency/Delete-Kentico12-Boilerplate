﻿using DeleteBoilerplate.Infrastructure.Models;

namespace $safeprojectname$.Models.Widgets.ContentBlockWidget
{
    public class ContentBlockWidgetViewModel : BaseWidgetViewModel
    {
        public string Text { get; set; }
    }
}
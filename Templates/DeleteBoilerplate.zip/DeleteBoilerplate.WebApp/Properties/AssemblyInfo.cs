﻿using System.Reflection;
using System.Runtime.InteropServices;
using DeleteBoilerplate.Common;
using DeleteBoilerplate.DynamicRouting.Attributes;
using DeleteBoilerplate.Projects.DI;
using LightInject;

[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("$guid1$")]

[assembly: AssemblyProduct("CMS")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("12.0.0.0")]
[assembly: AssemblyFileVersion("12.0.7139.13923")]
[assembly: AssemblyInformationalVersion("12.0.31")]

[assembly: CompositionRootType(typeof(CompositionRoot))]
[assembly: PageTypeRoutingAssembly]
[assembly: DeleteBoilerplateAssembly]


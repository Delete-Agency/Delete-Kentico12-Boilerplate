/*! Built with http://stenciljs.com */
(function(namespace,resourcesUrl){"use strict";
(function(resourcesUrl){Context.getString=((t,e,...n)=>t?t.getLocalization(e,n):""),Context.ensureStyles=((t,e)=>{if(HTMLElement.prototype.attachShadow)return t;const n=document.createElement("div");n.innerHTML=t;const r=n.querySelectorAll(":not(script):not(link):not(style)");return Array.prototype.forEach.call(r,t=>t.setAttribute(`data-${e}`,"")),n.innerHTML});
})(resourcesUrl);
})("components");
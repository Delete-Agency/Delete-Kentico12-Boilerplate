/*! Built with http://stenciljs.com */
const{h:o}=window.components,s=300,a=36,n=64;export{s as a,n as b,a as c};
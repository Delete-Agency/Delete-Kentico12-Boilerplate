/*! Built with http://stenciljs.com */
const{h:n}=window.components;var o;!function(n){n.Path="path",n.Guid="guid"}(o||(o={}));export{o as a};
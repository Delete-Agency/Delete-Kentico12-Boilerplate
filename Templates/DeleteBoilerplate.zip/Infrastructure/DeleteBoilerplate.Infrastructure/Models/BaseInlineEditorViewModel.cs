﻿namespace $safeprojectname$.Models
{
    public abstract class BaseInlineEditorViewModel
    {
        public string PropertyName { get; set; }
    }
}

﻿using CMS.Helpers;

namespace $safeprojectname$.Models
{
    public abstract class BaseWidgetViewModel
    {
        public string GetPlaceholder(string propertyName)
        {
            return ResHelper.GetString($"DeleteBoilerplate.Placeholder.{propertyName}");
        }
    }
}

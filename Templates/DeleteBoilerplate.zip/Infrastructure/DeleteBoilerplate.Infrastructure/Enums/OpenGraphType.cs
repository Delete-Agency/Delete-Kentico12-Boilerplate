﻿using $safeprojectname$.Attributes;

namespace $safeprojectname$.Enums
{
    public enum OpenGraphType
    {
        [StringValue("article")]
        Article,
        [StringValue("news")]
        News,
        [StringValue("website")]
        Website,
        [StringValue("profile")]
        Profile
    }
}

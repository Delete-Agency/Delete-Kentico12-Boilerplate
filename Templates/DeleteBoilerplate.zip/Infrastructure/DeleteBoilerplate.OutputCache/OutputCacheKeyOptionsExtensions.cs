﻿using Kentico.Web.Mvc;

namespace $safeprojectname$
{
    public static class OutputCacheKeyOptionsExtensions
    {
        public static IOutputCacheKeyOptions VarByAssetsCookie(this IOutputCacheKeyOptions options)
        {
            options.AddCacheKey(new AssetsOutputCacheKey());
            return options;
        }
    }
}
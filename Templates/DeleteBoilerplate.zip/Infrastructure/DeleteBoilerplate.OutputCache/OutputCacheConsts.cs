﻿namespace $safeprojectname$
{
    public static class OutputCacheConsts
    {
        public static class VarByCustom
        {
            public const string Default = "Default";
            public const string OnlineMarketing = "OnlineMarketing";
        }

        public static class CacheProfiles
        {
            public const string Default = "Default";
        }
    }
}

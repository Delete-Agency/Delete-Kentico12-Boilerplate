﻿using CMS.DocumentEngine;

namespace $safeprojectname$.Contexts
{
    public interface IRequestContext
    {
        int? ContextItemId { get; set; }

        TreeNode ContextItem { get; set; }

        bool ContextItemResolved { get; set; }

        bool ContextResolved { get; set; }

        bool IsPreview { get; set; }
    }
}

﻿using System;

namespace $safeprojectname$.Attributes
{
    [AttributeUsage(AttributeTargets.Assembly)]
    public class PageTypeRoutingAssemblyAttribute : Attribute
    {
    }
}
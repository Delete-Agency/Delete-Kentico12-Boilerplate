﻿using Kentico.PageBuilder.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public abstract class BaseWidgetController<TPropertiesType> : WidgetController<TPropertiesType> where TPropertiesType : class, IWidgetProperties, new()
    {
    }
}
﻿using $safeprojectname$.Contexts;
using $safeprojectname$.Contexts.Implementation;
using LightInject;

namespace $safeprojectname$.DI
{
    public class CompositionRoot : ICompositionRoot
    {
        public void Compose(IServiceRegistry serviceRegistry)
        {
            serviceRegistry.RegisterScoped<IRequestContext, RequestContext>();
        }
    }
}
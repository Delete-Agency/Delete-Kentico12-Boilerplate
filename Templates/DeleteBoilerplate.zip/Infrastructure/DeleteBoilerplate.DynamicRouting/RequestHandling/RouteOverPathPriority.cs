﻿using System;

namespace $safeprojectname$.RequestHandling
{
    public class RouteOverPathPriority : Attribute
    {
    }
}
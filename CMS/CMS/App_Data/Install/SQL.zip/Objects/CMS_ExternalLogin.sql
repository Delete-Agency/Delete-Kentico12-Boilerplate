SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_ExternalLogin](
	[ExternalLoginID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[LoginProvider] [nvarchar](200) NULL,
	[IdentityKey] [nvarchar](200) NULL,
 CONSTRAINT [PK_CMS_ExternalLogin] PRIMARY KEY CLUSTERED 
(
	[ExternalLoginID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_CMS_ExternalLogin_UserID] ON [dbo].[CMS_ExternalLogin]
(
	[UserID] ASC
)
GO
ALTER TABLE [dbo].[CMS_ExternalLogin] ADD  CONSTRAINT [DEFAULT_CMS_ExternalLogin_UserID]  DEFAULT ((0)) FOR [UserID]
GO
ALTER TABLE [dbo].[CMS_ExternalLogin]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ExternalLogin_UserID_CMS_User] FOREIGN KEY([UserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_ExternalLogin] CHECK CONSTRAINT [FK_CMS_ExternalLogin_UserID_CMS_User]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_CMS_Session_Update_Bulk]
@Sessions Type_CMS_SessionTable READONLY
AS
BEGIN
	MERGE [CMS_Session] sessTable
	USING @Sessions sessType
	ON sessTable.[SessionIdentificator] = sessType.[SessionIdentificator]

	WHEN MATCHED THEN
		UPDATE
		SET sessTable.[SessionUserID] = sessType.[SessionUserID],
			sessTable.[SessionLocation] = sessType.[SessionLocation],
			sessTable.[SessionLastActive] = sessType.[SessionLastActive],
			sessTable.[SessionLastLogon] = sessType.[SessionLastLogon],
			sessTable.[SessionExpires] = sessType.[SessionExpires],
			sessTable.[SessionExpired] = sessType.[SessionExpired],
			sessTable.[SessionSiteID] = sessType.[SessionSiteID],
			sessTable.[SessionUserIsHidden] = sessType.[SessionUserIsHidden],
			sessTable.[SessionFullName] = sessType.[SessionFullName],
			sessTable.[SessionEmail] = sessType.[SessionEmail],
			sessTable.[SessionUserName] = sessType.[SessionUserName],
			sessTable.[SessionNickName] = sessType.[SessionNickName],
			sessTable.[SessionUserCreated] = sessType.[SessionUserCreated],
			sessTable.[SessionContactID] = sessType.[SessionContactID]

	WHEN NOT MATCHED BY TARGET THEN
		INSERT ([SessionIdentificator], [SessionUserID], [SessionLocation], [SessionLastActive], [SessionLastLogon], [SessionExpires], [SessionExpired], [SessionSiteID], [SessionUserIsHidden],[SessionFullName] ,[SessionEmail],[SessionUserName],[SessionNickName],[SessionUserCreated],[SessionContactID]) 
		VALUES (sessType.[SessionIdentificator], sessType.[SessionUserID], sessType.[SessionLocation], sessType.[SessionLastActive], sessType.[SessionLastLogon], sessType.[SessionExpires], sessType.[SessionExpired], sessType.[SessionSiteID], sessType.[SessionUserIsHidden], sessType.[SessionFullName], sessType.[SessionEmail], sessType.[SessionUserName], sessType.[SessionNickName], sessType.[SessionUserCreated], sessType.[SessionContactID]);

END


GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_Personas_ReevaluateAllContacts]
@ContactIDs Type_CMS_OrderedIntegerTable readonly
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @CurrentTime datetime2(7);
	SET @CurrentTime = GetDate();

	DECLARE @InputContactsCount int;
	SET @InputContactsCount = (SELECT COUNT(1) FROM @ContactIDs);

	IF @InputContactsCount = 0
	BEGIN
		UPDATE [OM_Contact]
			SET [ContactPersonaID] = [PersonaID]
			FROM [OM_Contact]
			INNER JOIN 
			(
				SELECT 	
					[ContactID], 	
			
					-- If persona's treshold is no longer reached, set NULL to the ContactPersonaID column 
					CASE WHEN ( 1.0 * [TotalPoints] / [PersonaPointsThreshold] >= 1 ) 
					THEN [PersonaID]
					ELSE NULL
					END AS [PersonaID]	
		
					-- Order personas for contact by quotient to be able to retrieve the persona with highest quotient
					, ROW_NUMBER() OVER (PARTITION BY [ContactID] ORDER BY (1.0 * [TotalPoints] / [PersonaPointsThreshold]) DESC) AS [RowNumber]

				FROM [Personas_Persona] p
				INNER JOIN
				(
					   SELECT [ScoreID], [ContactID], SUM([Value]) AS [TotalPoints]
					   FROM [OM_ScoreContactRule] 
					   WHERE ([Expiration] IS NULL OR [Expiration] >= @CurrentTime)
					   GROUP BY [ScoreID], [ContactID]
				) AS [First] 
				ON p.PersonaScoreID = [First].ScoreID	
				WHERE p.PersonaEnabled = 1
			) AS [Second]
			ON [OM_Contact].ContactID = [Second].ContactID
			WHERE [Second].RowNumber = 1
			AND (ISNULL([ContactPersonaID], 0) != ISNULL([PersonaID], 0))
		END

	ELSE 

		BEGIN
			UPDATE [OM_Contact]
			SET [ContactPersonaID] = [PersonaID]
			FROM [OM_Contact]
		     INNER JOIN
			(
				SELECT  		
					[ContactID], 	
						
					-- If persona's treshold is no longer reached, set NULL to the ContactPersonaID column 
					CASE WHEN ( 1.0 * [TotalPoints] / [PersonaPointsThreshold] >= 1 ) 
					THEN [PersonaID]
					ELSE NULL
					END AS [PersonaID]	
		
					-- Order personas for contact by quotient to be able to retrieve the persona with highest quotient
					, ROW_NUMBER() OVER (PARTITION BY [ContactID] ORDER BY (1.0 * [TotalPoints] / [PersonaPointsThreshold]) DESC) AS [RowNumber]

				FROM [Personas_Persona] p 
				INNER JOIN
				(
					   SELECT [ScoreID], [ContactID], SUM(scr.[Value]) AS [TotalPoints]
					   FROM [OM_ScoreContactRule] scr INNER JOIN @ContactIDs cid
					   ON scr.[ContactID] = cid.[Value]
					   WHERE (scr.[Expiration] IS NULL OR scr.[Expiration] >= @CurrentTime)
					   GROUP BY [ScoreID], [ContactID]
				) AS [First] 
				ON p.PersonaScoreID = [First].ScoreID	
				WHERE p.PersonaEnabled = 1 
			) AS [Second]
			ON [OM_Contact].ContactID = [Second].ContactID
			WHERE [Second].RowNumber = 1
			AND (ISNULL([ContactPersonaID], 0) != ISNULL([PersonaID], 0))
		END
END


GO

CREATE TYPE [dbo].[Type_CMS_BigIntTable] AS TABLE(
	[Value] [bigint] NULL
)
GO
